<!-- BEGIN: Header-->
<div class="content-overlay"></div>
<div class="header-navbar-shadow"></div>
<nav class="header-navbar navbar-expand-lg navbar navbar-with-menu floating-nav navbar-light navbar-shadow">
    <div class="navbar-wrapper">
        <div class="navbar-container content">
            <div class="navbar-collapse" id="navbar-mobile">
                <div class="mr-auto float-left bookmark-wrapper d-flex align-items-center">
                    <ul class="nav navbar-nav">
                        <li class="nav-item mobile-menu d-xl-none mr-auto">
                            <a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#">
                                <i class="ficon feather icon-menu"></i>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav bookmark-icons">
                        <!-- li.nav-item.mobile-menu.d-xl-none.mr-auto-->
                        <!--   a.nav-link.nav-menu-main.menu-toggle.hidden-xs(href='#')-->
                        <!--     i.ficon.feather.icon-menu-->
                    </ul>
                </div>
                <ul class="nav navbar-nav ">

                            <li class="dropdown dropdown-user nav-item float-right">
                                <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                                    <div class="user-nav d-sm-flex d-none" style="font-size: 14px;">
                                        <span class="user-name text-bold-600"><?php echo e(12); ?></span>
                                      
                                    </div>
                                    <span>
                                <img class="round" src="<?php echo e(asset('login.png')); ?>"
                                     alt="avatar" height="40" width="40"/>
                                        
                            </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#">
                                        <i class="feather icon-user"></i> Mon Compte
                                    </a>
                                  
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                                        <i class="icon icon-login-page icon-fw mr-2 mr-sm-1"></i><?php echo e(__('Déconnexion')); ?>

                                    </a>
                                </div>
                            </li>
                            <li class="nav-item d-none d-lg-block">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item d-none d-lg-block">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                                </li>
                            <?php endif; ?>

                </ul>
            </div>
        </div>
    </div>
</nav>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<!-- END: Header-->

